# gem5 STREAMING (H2) evaluation — results

Platform model: Intel 8592+ (EMR) CHI/Ruby, O3CPU 1.9GHz, L1d 48KiB/12, L2 2MiB/16,
L3(HNF) 5MiB/20, SimpleMemory, DRAM 98ns / CXL 203ns. Binary build_Intel_8592/gem5.opt
(X86+CHI, py3.11/uv). Fixes applied: (1) benchmark calls gem5_set_streaming on fact;
(2) gem5 setstreaming flushes all TLBs; (3) run_morsel prefault (phys_bytes) now tagged.

## 1. Go/no-go: does prefetch bandwidth survive non-allocation? (single core, 16MiB stream)

| arm | bandwidth (GB/s) | IPC | LLC data-array writes |
|-----|-----------------:|----:|----------------------:|
| WB, MSHR=16 | 4.24 | 0.209 | 529,330 |
| H2, MSHR=16 | 4.90 | 0.209 | 300,238 |
| WC, MSHR=16 | 4.60 | 0.204 | 289,695 |
| **WB, MSHR=48** | **5.44** | 0.210 | 529,309 |
| **H2, MSHR=48** | **5.82** | 0.211 | 353,739 |
| **WC, MSHR=48** | **4.60** | 0.204 | 289,698 |

VERDICT: PASS. At MSHR=16 all arms are MSHR-capped (~16x64B/203ns ~= 5 GB/s), so WB
cannot show its prefetch advantage. At MSHR=48 the gap appears: H2 (5.82) ~= WB (5.44)
and both > WC (4.60, prefetch off). H2 attains a WC-like LLC footprint (354k fills vs
WB 529k, ~ WC 290k) with WB-like bandwidth -> non-allocation preserves prefetch MLP.
NOTE: bandwidth verdict is MSHR-sensitive; report the sweep, not a single point.

## 2. Fused single-core (morsel): does H2 recover the same-thread tax?

16MiB CXL fact stream interleaved with a 2.6MB LLC-resident hot table, single core.

| metric | WB | H2 |
|--------|---:|---:|
| LLC data-array writes | 1,178,728 | 742,046 (-37%) |
| hot-table cost (cyc/access) | 80.10 | 78.06 (-2.5%) |
| join throughput (Mtuple/s) | 23.72 | 24.34 |

FINDING: H2 clearly ENGAGES (37% fewer LLC data-array writes -- the fact stream is
bypassing the LLC), yet the fused hot-table access cost improves only 2.5% (80.1->78.1
cyc, ~2 cycles). So removing shared-LLC allocation recovers almost none of the
same-thread fused tax. This CORROBORATES the real-hardware mechanism_decomp result
(<=31% of the fused tax is LLC-resident): the tax lives mostly outside the shared-LLC
admission channel H2 addresses (private-cache / MSHR / execution-overlap). A quiescent no-stream baseline (m2_q) measures 79.97 cyc/access -- essentially
EQUAL to loaded WB (80.10), i.e. the gem5 SE model exhibits ~0 same-thread fused
tax (vs 1.47x on real hardware). So gem5 cannot test fused recovery -- there is no
shared-LLC fused tax in the model to remove (the -2.5pct wb->h2 is within run noise:
quiescent 79.97 ~ WB 80.10 ~ H2 78.06). This is CONSISTENT with the hardware
mechanism_decomp: the fused tax is not a shared-LLC phenomenon, so a shared-LLC
model shows no fused tax and an LLC-admission fix (H2) has nothing to recover.
The hardware decomposition remains the authority on the fused case.
(Note: earlier m_wb/m_h2 were INVALID -- run_morsel prefaults with phys_bytes, so the
first setstreaming patch missed that path; now fixed, H2 confirmed engaging.)

## 3. Cross-core recovery: WB vs STREAMING aggressor on a shared-LLC victim

Victim = pointer-chase over 2650KiB (53pct of the shared 5MiB LLC) on cpu0, 3M iters;
one aggressor on cpu1 streaming a 10MB region from CXL. Victim cost = cpu0 cycles / iter.

| arm | victim cyc/iter | tax | LLC data-array writes |
|-----|----------------:|----:|----------------------:|
| alone (dummy)         | 33.86 | 1.000x | 1,301,494 |
| + WB aggressor        | 45.19 | **1.335x** | 4,475,366 |
| + STREAMING aggressor | 34.57 | **1.021x** | 1,230,414 |

FINDING: the WB aggressor taxes the co-running victim 1.335x; the STREAMING (H2)
aggressor returns it to 1.021x -- **93.8pct of the tax recovered** -- at full aggressor
streaming (it bypasses the LLC: 1.23M fills ~ the alone 1.30M, vs WB 4.48M). This is
the surviving sufficiency leg: non-allocation protects a co-runner LLC-resident
working set. Scope: single victim+aggressor pair, one WSS point (53pct LLC), SE model.

## 4. Multi-core H2 bandwidth survival (e2e gating prereq) — PASS
4-core stream-smoke, MSHR=48, 32MiB total (8MiB/core), aggregate BW = 32MiB/total_sec.
| arm | aggregate BW (GB/s) | LLC fills (sum HNFs) |
|---|---:|---:|
| WB | 6.23 | 1,063,653 |
| H2 | 7.73 | 589,928 (-45%) |
| WC (prefetch off) | 5.62 | 556,161 |
VERDICT: bandwidth SURVIVES at 4 cores. H2 >= WB > WC, H2 holds WC-like LLC
footprint. H2 actually EXCEEDS WB (7.73 vs 6.23) because non-allocation avoids
the LLC fill-path contention WB creates. Aggregate is CXL-path-limited (~6-8 GB/s
regardless of cores) -> this is the ratio/survival result, not absolute scaling.
8-core repeat launched for robustness. => e2e co-runner GREEN-LIT.
